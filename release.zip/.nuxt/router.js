import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3c313636 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _ce9afa2a = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _7dd622dd = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _39ffb01d = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _d19337a2 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _30625c79 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _20c9f36a = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _3c313636,
    children: [{
      path: "",
      component: _ce9afa2a,
      name: "home"
    }, {
      path: "/login",
      component: _7dd622dd,
      name: "login"
    }, {
      path: "/register",
      component: _7dd622dd,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _39ffb01d,
      name: "profile"
    }, {
      path: "/settings",
      component: _d19337a2,
      name: "settings"
    }, {
      path: "/editor",
      component: _30625c79,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _20c9f36a,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
